package com.zosh.tasksubmitionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskSubmitionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
