package com.zosh.tasknotificationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskNotificationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskNotificationServiceApplication.class, args);
	}

}
